/*
    bitmask 1.3
    Copyright (C) 2002-2004 Ulf Ekstrom except for the bitcount function which
    is copyright (C) Donald W. Gillies, 1992.
  
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.
 
    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.
 
    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#ifndef BITMASK_H
#define BITMASK_H
#include <limits.h>

/* Define INLINE for different compilers. */
#ifndef INLINE
# ifdef __GNUC__
#  define INLINE inline
# else
#  ifdef _MSC_VER
#   define INLINE __inline
#  else
#   define INLINE
#  endif
# endif
#endif

#define BITW unsigned long int
#define BITW_LEN (sizeof(BITW)*CHAR_BIT)
#define BITW_MASK (BITW_LEN - 1)
#define BITN(n) ((BITW)1 << (n))

typedef struct bitmask
{
  int w,h;
  BITW *bits;
} bitmask_t;

/* Creates a bitmask of width w and height h.
 * The mask is automatically cleared when created.
 */
bitmask_t *bitmask_create(int w, int h);
void bitmask_free(bitmask_t *m);

void bitmask_clear(bitmask_t *m);
void bitmask_fill(bitmask_t *m);

/* Returns nonzero if the bit at (x,y) is set. 
 * Coordinates start at (0,0)
 */
static INLINE int bitmask_getbit(const bitmask_t *m,int x,int y) 
{ 
  return m->bits[x/BITW_LEN*m->h + y] & BITN(x & BITW_MASK); 
}

/* Sets the bit at (x,y) */
static INLINE void bitmask_setbit(bitmask_t *m,int x,int y)
{ 
  m->bits[x/BITW_LEN*m->h + y] |= BITN(x & BITW_MASK); 
}

/* Clears the bit at (x,y) */
static INLINE void bitmask_clearbit(bitmask_t *m,int x,int y)
{ 
  m->bits[x/BITW_LEN*m->h + y] &= ~BITN(x & BITW_MASK); 
}

/* Returns nonzero if the masks overlap with the given offset. */
int bitmask_overlap(const bitmask_t *a,const bitmask_t *b,int xoffset, int yoffset);

/* Like bitmask_overlap(), but will also give a point of intersection.
 * x and y are given in the coordinates of mask a, and are untouched
 * if there is no overlap.
 */
int bitmask_overlap_pos(const bitmask_t *a,const bitmask_t *b,
			int xoffset, int yoffset, int *x, int *y);

/* Returns the number of overlapping 'pixels' */
int bitmask_overlap_area(const bitmask_t *a,const bitmask_t *b,int xoffset, int yoffset);

/* Draws mask b onto mask a (bitwise OR) 
 * Can be used to compose large (game background?) mask from 
 * several submasks, which may speed up the testing. 
 */
void bitmask_draw(bitmask_t *a,bitmask_t *b,int xoffset, int yoffset);

#endif
