// quadtree.h


#include "gameobj.h"

// Node - a node in the quadtree
class Node
{
public:
	int			x, y;
	int			halfwidth;
	Node		*child[4];

	Node(int x,int y,int hw);
};

// Tjunc - a node from which to create linked lists pointing to game objects
class Tjunc
{
public:
	int			magic;			// TEMP
	GameObject	*gameObject;
	Tjunc		*next;

	Tjunc( GameObject *g, Tjunc *n);
};


// QuadTree - a tree structure to allow fast spatial lookup of game objects
class QuadTree
{
public:
	QuadTree( int width );

	void add( GameObject *gobj );

	void render( void );

private:
	void subdivide( Node *node, int level );
	void addReference(int x, int y, GameObject *gobj);
	void QuadTree::render( Node *node, int cullcode, int level );
	Node		*root;
	int			traversal_count;
};