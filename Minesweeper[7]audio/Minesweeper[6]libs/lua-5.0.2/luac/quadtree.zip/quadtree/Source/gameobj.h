// gameobj.h


class Vec3
{
public:
	int		x, y, z;
};

class BoundingBox
{
public:
	Vec3	min;
	Vec3	max;
};

class GameObject
{
public:
	int			id;			// unique identifier
	int			visited;	// frame counter of last tree traversal
	Vec3		position;
	BoundingBox bbox;		// world-axis aligned bounding box

	void render( void );

	GameObject();
};