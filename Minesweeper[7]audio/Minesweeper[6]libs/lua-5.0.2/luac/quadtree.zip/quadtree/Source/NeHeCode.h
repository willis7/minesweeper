
extern bool		keys[256];
extern int		mouse_x, mouse_y;
extern int		mouse_b;			// mouse button bit mask

void message( char * str );