char *demo_title( void );

bool initialize( void );

bool draw_scene( void );

