// gameobj.cpp


#include "gameobj.h"
#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include "assert.h"

GameObject::GameObject( void )
{
	id = -1;	// to catch uninitialized objects
	visited = -1;
}

void GameObject::render( void )
{
	assert(id != -1 );
	
	// put a pixel at position.x, position.y
	// (put your state of the art model rendering here)
	//
	glColor3f(1, 0, 1); 
	glPointSize(5);
	glBegin(GL_POINTS);
	glVertex3f( position.x, position.y, 0.0 );
	glEnd();

	glBegin(GL_LINE_LOOP);
	glLineWidth(1);
	glVertex3f( bbox.min.x, bbox.min.y, 0.0 );
	glVertex3f( bbox.max.x, bbox.min.y, 0.0 );
	glVertex3f( bbox.max.x, bbox.max.y, 0.0 );
	glVertex3f( bbox.min.x, bbox.max.y, 0.0 );
	glEnd();

}
