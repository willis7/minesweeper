// quadtree.cpp


#include <stdio.h>
#include "quadtree.h"
#include "frustum.h"
#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <assert.h>

// Number of levels in the tree
#define TREE_LEVELS		5


// Wind directions of the 4 subquads per quad
enum { SW=0, SE, NW, NE };




Tjunc::Tjunc( GameObject *g, Tjunc *n)
{
	magic = 12345;		// debugging aid to test whether pointer points to Tjunc
	gameObject = g;
	next = n;
}

Node::Node( int ix, int iy, int hw )
{
	x = ix;
	y = iy;
	halfwidth = hw;
	child[0] = child[1] = child[2] = child[3] = NULL;
}

void render_node( Node *node, int level, int cullcode )
{
	if(level <= 0)
		return;
	glLineWidth(level);	// thicker lines for high-level (large) nodes

	switch( cullcode )
	{
	case OUTSIDE_FRUSTUM:				glColor3f(.5, .5, .5); break;// grey
	case INSIDE_FRUSTUM:				glColor3f(0, 1, 0); break;// green
	case PARTIALLY_INSIDE_FRUSTUM:		glColor3f(0, 0, .5); break;// blue
	default:							glColor3f(1,0,0); break;
	}

	// draw frame 
	glBegin(GL_LINE_LOOP);
	 glVertex3f( node->x - node->halfwidth, node->y - node->halfwidth, 0 );
	 glVertex3f( node->x - node->halfwidth, node->y + node->halfwidth, 0 );
	 glVertex3f( node->x + node->halfwidth, node->y + node->halfwidth, 0 );
	 glVertex3f( node->x + node->halfwidth, node->y - node->halfwidth, 0 );
	glEnd();
}

// subdivide - subdive a quad in 4 subquads, used during quadtree construction only
//
void QuadTree::subdivide( Node *node, int level )
{
	int		hw;

	if( level == 1 )	// lowest level of nodes, don't subdivide any further
		return;

	// Subdivide this node into 4 and subdivide those even further if necessary
	hw = node->halfwidth/2;
	node->child[SW] = new Node(node->x - hw, node->y - hw, hw);
	node->child[SE] = new Node(node->x + hw, node->y - hw, hw);
	node->child[NW] = new Node(node->x - hw, node->y + hw, hw);
	node->child[NE] = new Node(node->x + hw, node->y + hw, hw);

	subdivide(node->child[SW], level-1);
	subdivide(node->child[SE], level-1);
	subdivide(node->child[NW], level-1);
	subdivide(node->child[NE], level-1);

	return;
}

QuadTree::QuadTree( int width )
{
	// Construct a quadtree of TREE_LEVELS levels deep
	traversal_count = 0;
	root = new Node( width/2, width/2, width/2 );
	subdivide(root, TREE_LEVELS);

	return;
}

// addReference - add a link to the game object into the linked list for position (x,y)
//                does nothing if the game object is already in the list.
//
void QuadTree::addReference(int x, int y, GameObject *gobj)
{
	Node	*node;
	Node	*prev;		// to point to parent of node
	Tjunc	*ptr;
	Tjunc	*list;
	
	assert( TREE_LEVELS > 1 ); 

	// Search in quadtree
	node = root;
	for(int level = TREE_LEVELS; level > 0; level--)
	{
		prev = node;
		if( x <= node->x && y <= node->y ) 
			node = node->child[SW];
		else if( x > node->x && y <= node->y ) 
			node = node->child[SE];
		else if( x <= node->x && y > node->y ) 
			node = node->child[NW];
		else 
			node = node->child[NE];
	}

	// We're below the last level of the tree now, the pointer points to a 
	// linked list of Tjunc elements.
	// cast the node pointer to a Tjunc pointer so we can search
	// the linked list
	list = (Tjunc*) node;		
	
	// First check if the game object is already in the linked list
	ptr = list;
	while (ptr != NULL)
	{
		if(ptr->gameObject->id == gobj->id )	// found it
			return;								// it's already in the list, do nothing!
		ptr = ptr->next;
	}

	// Add new item to head of the list
	list = new Tjunc( gobj, list );

	// And hang the list in the tree

	if( x <= prev->x && y <= prev->y ) 
		prev->child[SW] = (Node*)list;
	else if( x > prev->x && y <= prev->y ) 
		prev->child[SE] = (Node*)list;
	else if( x <= prev->x && y > prev->y ) 
		prev->child[NW] = (Node*)list;
	else 
		prev->child[NE] = (Node*)list;

	return;
}

void QuadTree::add( GameObject *gobj )
{
	// Add references for each corner of the bounding box

	addReference( gobj->bbox.max.x, gobj->bbox.max.y, gobj );
	addReference( gobj->bbox.max.x, gobj->bbox.min.y, gobj );
	addReference( gobj->bbox.min.x, gobj->bbox.max.y, gobj );
	addReference( gobj->bbox.min.x, gobj->bbox.min.y, gobj );
}


void QuadTree::render( Node *node, int cullcode, int level )
{
	Tjunc		*ptr;
	BBOX		bbox;


	if(level == 0)	// reached past leaf of quadtree, into linked list?
	{

		// then the pointer points to a linked list
		ptr = (Tjunc*) node;

		// render all game objects in the linked list
		// TODO: add logic to avoid double renders of same object if it's in multiple lists
		while(ptr != NULL)
		{
			assert( ptr->magic == 12345 );

			if( ptr->gameObject->visited < traversal_count )
			{
				ptr->gameObject->visited = traversal_count;
				ptr->gameObject->render();
			}
			ptr = ptr->next;
		}

		return;
	}

	assert( node != NULL );

	if( cullcode == PARTIALLY_INSIDE_FRUSTUM )	// parent quad is partially visible
	{											// test this child quad
		// Create bounding box for this quad
		bbox.min[0] = (float) node->x - node->halfwidth;
		bbox.min[1] = 0;
		bbox.min[2] = (float) node->y - node->halfwidth;
	
		bbox.max[0] = (float) node->x + node->halfwidth;
		bbox.min[1] = 0;
		bbox.max[2] = (float) node->y + node->halfwidth;

		cullcode = cull_against_frustum(&bbox);
		
		if(cullcode == OUTSIDE_FRUSTUM)			// this child is not visibile
   		{
			render_node( node, level, cullcode );
			return;								// exit
		}
	}
	render_node( node, level, cullcode );

	render( node->child[SW], cullcode, level-1 );
	render( node->child[SE], cullcode, level-1 );
	render( node->child[NW], cullcode, level-1 );
	render( node->child[NE], cullcode, level-1 );
}


	
void QuadTree::render( void )
{
	traversal_count++;
	render(root, PARTIALLY_INSIDE_FRUSTUM, TREE_LEVELS);
}

