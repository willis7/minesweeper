/*----------------------------------------------------------------
 * demo.cpp -- demo program
 *----------------------------------------------------------------
 * (c) 2001 by Marco Monster, Monstrous Software
 * http://home.planet.nl/~monstrous
 *
 *
 */

#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <assert.h>
#include <math.h>

#include "NeHeCode.h"
#include "demo.h"

#include "quadtree.h"
#include "frustum.h"

#ifndef M_PI						/* if not in math.h, i.e. MSVC */
    #define M_PI 3.1415926
#endif


char *demo_title( void )
{
	return "Quad Tree demo";
}


#define NUM_OBJECTS		20
#define AREA_SIZE		256
#define BORDER			10

/* Types
 */
 
struct camera {
	float x, y, z;
	float rotation;
};

/* Globals
 */


struct camera	camera = {
	AREA_SIZE/2.0f, AREA_SIZE/2.0f, 0,
	0.0f
};

static float 	angle_speed = .005;
static float	move_speed = 0.1;

static QuadTree	*quadTree = NULL;
static GameObject *objects[ NUM_OBJECTS ];

/* Functions
 */
 

void set_projection (void)
{
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();

	// Orthogonal projection!
	//
	glOrtho(-BORDER,AREA_SIZE+BORDER,-BORDER,AREA_SIZE+BORDER,-1,1);				

	// Set the modelview matrix to be the identity matrix
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
}


void user_input (void)
{
	// Get keyboard and mouse input

	if (keys[VK_LEFT] || ((mouse_b & 1)&&mouse_x<320)) 
	{
		camera.rotation += angle_speed;
		if (camera.rotation > M_PI * 2.0)
			camera.rotation -= M_PI * 2.0;
	}
	if (keys[VK_RIGHT]|| ((mouse_b & 1)&&mouse_x>320)) 
	{
		camera.rotation -= angle_speed;
		if (camera.rotation < 0)
			camera.rotation += M_PI * 2.0;
	}
	if (keys[VK_UP]) camera.x += move_speed;
	if (keys[VK_DOWN]) camera.x -= move_speed;

	if (keys[VK_PRIOR]) // page up
		camera.y -= move_speed;
	if (keys[VK_NEXT]) // page down
		camera.y += move_speed;
}



void display( QuadTree *quadTree )
{
    // Clear the RGB buffer and the depth buffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// render the quadtree and all the visible game objects that hang in the tree
	quadTree->render();				

/*
	// you could use this to just show *all* the objects 

	for(int i = 0; i < NUM_OBJECTS; i++)
	{
		objects[i]->render();
	}
*/
}



bool initialize( void )
{
	int			i;

	set_projection();

	// Set the clear color to white
	glClearColor(1.0, 1.0, 1.0, 0.0);

	
	quadTree = new QuadTree( AREA_SIZE );

	srand( 1234 ); // seed randomizer


	for(i = 0; i < NUM_OBJECTS; i++)
	{
		objects[i] = new GameObject;

		objects[i]->id = i;
		objects[i]->position.x = rand() % AREA_SIZE;
		objects[i]->position.y = rand() % AREA_SIZE;

		objects[i]->bbox.max.x = objects[i]->position.x + 6;
		objects[i]->bbox.min.x = objects[i]->position.x - 6;
		objects[i]->bbox.max.y = objects[i]->position.y + 10;
		objects[i]->bbox.min.y = objects[i]->position.y - 10;
		objects[i]->bbox.min.z = 0;
		objects[i]->bbox.max.z = 0;

		quadTree->add( objects[i] );
	}

	// place camera 
	// (Note: frustum code assumes the horizontal plane is XZ and Y points up)
	init_frustum( camera.rotation, -camera.x, 0, -camera.y ); 

	return true;
}

void render_cam( void )
{
	float	fov2 = (float)( M_PI/6.0f );

	glColor3f(1, 0, 0); 
	glPointSize(4);
	glBegin(GL_POINTS);
	glVertex3f( camera.x, camera.y, 0 );
	glEnd();


	glLineWidth(1);
	glBegin(GL_LINES);
	glVertex3f( camera.x, camera.y, 0 );
	glVertex3f( camera.x+500.0*cos(camera.rotation-fov2), camera.y-500.0*sin(camera.rotation-fov2), 0 );
	glVertex3f( camera.x, camera.y, 0 );
	glVertex3f( camera.x+500.0*cos(camera.rotation+fov2), camera.y-500.0*sin(camera.rotation+fov2), 0 );
	glEnd();

}

bool draw_scene ( void )
{
	// get user input
	user_input();

	// update camera angle
	// (Note: frustum code assumes the horizontal plane is XZ and Y points up)
	init_frustum( camera.rotation, -camera.x, 0, -camera.y ); 

	// show the model
	display( quadTree );

	render_cam();


	return true;
}
