// FILE: frustum.h

//culling codes
enum { OUTSIDE_FRUSTUM, INSIDE_FRUSTUM, PARTIALLY_INSIDE_FRUSTUM };	


typedef float VECTOR[3];

typedef struct BBOX
{
	VECTOR min;
	VECTOR max;
} BBOX;


void extract_frustum( void );
void init_frustum( float ry, float x, float y, float z );
int cull_against_frustum(  BBOX *bbox );


