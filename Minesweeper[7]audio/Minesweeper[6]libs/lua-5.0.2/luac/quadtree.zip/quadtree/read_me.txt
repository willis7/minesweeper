Quad Tree Demo
==============
version 1.0


Introduction
------------
This is a demo of a quad tree used for visibility culling. This is a technique
you can use to speed up your game when you have lots of complicated game objects
in your game, but only a small portion can be seen at one time.  By using an 
efficient way to reject game objects that are out of view, you can keep a 
reasonable frame rate even for large levels with lots and lots of objects.


Explanation of the demo 
-----------------------
The window shows a top-down view or a square area that is the game world.
(Note: for the purpose of the demonstration this is a 2d view, the technique
of quad trees however applies particularly to 3d games.) The red dot is 
the camera, with a triangular region showing the field of view.
The purple boxes are the game objects.  The goal of the visibility culling is 
to only display those game objects that are in view.

As you can see the area is recursively subdivided into square regions (=quads).
The green quads are fully in view of the camera.  The grey quads are entirely out
of view.  The blue quads are partially visible.  Only the purple boxes in the
green and blue quads are ever shown.

Note how the quads are smallest along the edges of the camera's view (=the viewing
frustum).  This is because at the boundary the decisions about visibility of a quad
are made at the most detailed level.  Quads that are entirely out of view don't need
to be further refined, because the algorithm knows that all its subquads will be out
of view.

Use the left/right keys to rotate the camera and Up/Down/PgUp/PgDn to
move the camera.   


Finer points
------------
Game objects are generally not point sized. In other words, they have a certain size
and that means a game object may extend into two of four adjacent quads.  So, assuming
that each game object lies entirely within one particular quad is going to land us in 
trouble: an object may just pop into view as the viewing area (the frustum) crosses
an imaginary line between two quads.  Most annoying.  Therefore I've defined a bounding
box (actually: a 2d bounding rectangle rather than a 3d box) for each game object to 
indicate its size.  The game object will be rendered if any of the four corners lie in 
a visible quad. So in some cases there will be references from as many as four quads
to the same game object.  

To avoid the same object being rendered multiple times for the same frame, we update 
the game objects 'visited' attribute, when it's rendered. If we encounter the same 
object again while still rendering the same frame, we'll know that we can skip it.


Building
--------
The source code is in C++ and suitable for MSVC. No additional libraries are required.


Credits
-------
The startup code is based on Jeff Molofee's base code (nehe.gamedev.net).
The frustum code is based on Mark Morley's clipping tutorial at markmorley.com.


Marco Monster
Monstrous Software
december 2001
http:\\home.planet.nl\~monstrous